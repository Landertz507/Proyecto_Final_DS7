<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
?>
<?php

    //<!-- filepath: c:\wamp64\www\INVENTARIO-main\vistas\reportes.php -->?>
<?php

// Verifica si hay parámetros para exportar Excel
if(isset($_GET['excel'])) {
        require_once __DIR__ . "/../php/reportes_excel.php";

    exit();
}
?>

<div class="container is-fluid">
    <h1 class="title">Reportes</h1>
    <h2 class="subtitle">Estadísticas de ventas</h2>
</div>


<div class="container pb-6 pt-6">
    <!-- Filtros -->
    <form class="box" method="GET" action="">
        <input type="hidden" name="vista" value="reportes">
        <div class="columns">
            <div class="column">
                <label>Categoría:</label>
                <div class="select is-fullwidth">
                    <select name="categoria_id">
    <option value="0">Todas</option>
    <?php 
    if($categorias) {
        $hay_categorias = false;
        while($cat = $categorias->fetch(PDO::FETCH_ASSOC)) {
            $hay_categorias = true;
            $selected = (isset($_GET['categoria_id']) && $_GET['categoria_id'] == $cat['categoria_id']) ? 'selected' : '';
            echo '<option value="'.$cat['categoria_id'].'" '.$selected.'>'.$cat['categoria_nombre'].'</option>';
        }
        if(!$hay_categorias) {
            echo '<option disabled>No hay categorías</option>';
        }
    } else {
        echo '<option disabled>Error de conexión</option>';
    }
    ?>
</select>
                </div>
            </div>
            <div class="column">
                <label>Mes:</label>
                <input class="input" type="month" name="mes"
                       value="<?= isset($_GET['mes']) ? htmlspecialchars($_GET['mes']) : date('Y-m') ?>">
            </div>
            <div class="column">
                <button type="submit" name="generar" value="1" class="button is-info" style="width:100%;">
                    <i class="fas fa-chart-bar"></i> &nbsp; Generar Reporte
                </button>
            </div>
        </div>
    </form>

    <!-- Debug: Mostrar parámetros GET -->
    <?php if(isset($_GET['generar'])): ?>
    <div class="notification is-info is-light">
        Parámetros recibidos:<br>
        Mes: <?= htmlspecialchars($_GET['mes'] ?? 'No definido') ?><br>
        Categoría ID: <?= htmlspecialchars($_GET['categoria_id'] ?? '0') ?><br>
        Generar: <?= htmlspecialchars($_GET['generar']) ?>
    </div>
    <?php endif; ?>

    <!-- Gráficos y datos -->
     <?php if(isset($GET['generar'])) require_once __DIR__ . "/../php/reportes_datos.php"; ?>

    <!-- Botón para Excel -->
    <div class="has-text-centered mt-5">
        <a href="index.php?vista=reportes&excel=1&mes=<?= htmlspecialchars($_GET['mes'] ?? '') ?>&categoria_id=<?= htmlspecialchars($_GET['categoria_id'] ?? 0) ?>"
           class="button is-success is-medium <?= empty($_GET['generar']) ? 'is-static' : '' ?>">
            <i class="fas fa-file-excel"></i> &nbsp; Exportar a Excel
        </a>
    </div>
</div>

<!-- Incluir Font Awesome para iconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<style>
button[name="generar"] { display: block !important; width: 100% !important; background: #209cee !important; color: #fff !important; }
</style>