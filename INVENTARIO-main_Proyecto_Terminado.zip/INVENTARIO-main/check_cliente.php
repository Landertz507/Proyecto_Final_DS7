<?php
function is_cliente(){
    return isset($_SESSION['rol']) && $_SESSION['rol'] == 'cliente';
}

if(!is_cliente() && basename($_SERVER['PHP_SELF']) != 'cliente_registro.php'){
    header("Location: cliente_registro.php");
    exit();
}
?>