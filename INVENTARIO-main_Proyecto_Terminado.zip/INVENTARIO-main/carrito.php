<?php
session_start();

require_once __DIR__ . "/php/main.php";
// Crear la conexión
$conexion = conexion();


// Debug: Mostrar el contenido de la sesión
echo '<pre>'; print_r($_SESSION); echo '</pre>';

// Verifica que el usuario esté logueado
if(!isset($_SESSION['id'])) {
    echo '<div class="notification is-danger">Debes iniciar sesión para ver el carrito.</div>';
    exit;
}

// Mostrar items del carrito
$carrito = $conexion->query("
    SELECT p.*, c.cantidad 
    FROM carrito c
    JOIN producto p ON c.producto_id = p.producto_id
    WHERE c.usuario_id = {$_SESSION['id']}
");

foreach($carrito as $item){
    echo '<div class="cart-item">
            <span>'.$item['producto_nombre'].'</span>
            <input type="number" value="'.$item['cantidad'].'" min="1">
            <button class="eliminar" data-id="'.$item['producto_id'].'">🗑️</button>
          </div>';
}
?>
<button id="generarFactura" class="button is-success">Pagar</button>
<script>
$("#generarFactura").click(function(){
    $.post("./php/generar_factura.php", function(respuesta){
        alert("Factura generada: #" + respuesta.factura_id);
    });
});
</script>