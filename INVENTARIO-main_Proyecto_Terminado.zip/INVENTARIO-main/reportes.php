<?php
require_once "./php/main.php";

// Filtros
$categoria_id = isset($_GET['categoria_id']) ? limpiar_cadena($_GET['categoria_id']) : 0;
$mes = isset($_GET['mes']) ? limpiar_cadena($_GET['mes']) : date('m');

/*== 1. Reporte de inventario ==*/
if(isset($_GET['excel'])){
    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=reporte_inventario_".date('d-m-Y').".xls");

    $consulta = conexion();
    if($categoria_id>0){
        $productos = $consulta->query("SELECT * FROM producto WHERE categoria_id='$categoria_id'");
    }else{
        $productos = $consulta->query("SELECT * FROM producto");
    }
    
    echo "<table border='1'>";
    echo "<tr><th>Código</th><th>Nombre</th><th>Precio</th><th>Stock</th><th>Categoría</th></tr>";
    
    while($p = $productos->fetch(PDO::FETCH_ASSOC)){
        echo "<tr>
            <td>".$p['producto_codigo']."</td>
            <td>".$p['producto_nombre']."</td>
            <td>".$p['producto_precio']."</td>
            <td>".$p['producto_stock']."</td>
            <td>".obtener_categoria($p['categoria_id'])."</td>
        </tr>";
    }
    echo "</table>";
    exit();
}

/*== 2. Estadísticas de ventas ==*/
$ventas_mes = conexion()->query("
    SELECT p.producto_nombre, SUM(v.cantidad) as total_vendido, SUM(v.total_venta) as ingresos 
    FROM vendido_parte v
    INNER JOIN producto p ON v.producto_id=p.producto_id
    WHERE MONTH(v.fecha_venta)='$mes'
    GROUP BY v.producto_id
    ORDER BY total_vendido DESC
");

$top_ventas = $ventas_mes->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- HTML para mostrar estadísticas -->
<div class="container">
    <h2 class="title">Estadísticas de Ventas</h2>
    
    <!-- Filtros -->
    <form method="GET" class="mb-6">
        <div class="field">
            <label>Mes:</label>
            <input type="month" name="mes" value="<?= date('Y-m') ?>">
            <button type="submit" class="button is-info">Filtrar</button>
        </div>
    </form>

    <!-- Gráfico de pastel (usando Chart.js) -->
    <canvas id="chartVentas" width="400" height="400"></canvas>
    
    <!-- Tabla de productos más vendidos -->
    <table class="table is-bordered is-striped">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Unidades Vendidas</th>
                <th>Ingresos</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($top_ventas as $v): ?>
            <tr>
                <td><?= $v['producto_nombre'] ?></td>
                <td><?= $v['total_vendido'] ?></td>
                <td>$<?= number_format($v['ingresos'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <!-- Botón para exportar a Excel -->
    <a href="reportes.php?excel=1&categoria_id=<?= $categoria_id ?>" class="button is-success">
        Exportar a Excel
    </a>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Script para gráfico
    const ctx = document.getElementById('chartVentas').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: <?= json_encode(array_column($top_ventas, 'producto_nombre')) ?>,
            datasets: [{
                data: <?= json_encode(array_column($top_ventas, 'total_vendido')) ?>,
                backgroundColor: ['#FF6384','#36A2EB','#FFCE56','#4BC0C0','#9966FF']
            }]
        }
    });
</script>