<?php
session_start();
require_once __DIR__ . "./php/check_cliente.php";
require_once __DIR__ . "/php/main.php";

// Debug mejorado (opcional)
if(!isset($_SESSION['id'])) {
    echo '<div class="container">';
    echo '<div class="notification is-danger">';
    echo '<p>Debes iniciar sesión para ver el carrito.</p>';
    echo '<a href="login.php" class="button is-small is-link">Iniciar sesión</a>';
    echo '</div>';
    echo '<pre>Debug: Sesión no iniciada. Contenido de $_SESSION: ';
    print_r($_SESSION);
    echo '</pre></div>';
    exit;
}

$conexion = conexion();

// Consulta segura con prepared statements
$query = $conexion->prepare("
    SELECT p.*, c.cantidad 
    FROM carrito c
    JOIN producto p ON c.producto_id = p.producto_id
    WHERE c.usuario_id = :usuario_id
");
$query->execute([':usuario_id' => $_SESSION['id']]);
$carrito = $query->fetchAll(PDO::FETCH_ASSOC);

// HTML del carrito
?>
<div class="container">
    <h2 class="title is-4">Mi Carrito</h2>
    
    <?php if(empty($carrito)): ?>
        <div class="notification is-warning">Tu carrito está vacío.</div>
    <?php else: ?>
        <div class="cart-items">
            <?php foreach($carrito as $item): ?>
            <div class="box cart-item">
                <article class="media">
                    <figure class="media-left">
                        <p class="image is-64x64">
                            <img src="./img/productos/<?= htmlspecialchars($item['producto_foto']) ?>">
                        </p>
                    </figure>
                    <div class="media-content">
                        <p><strong><?= htmlspecialchars($item['producto_nombre']) ?></strong></p>
                        <p>Precio: $<?= number_format($item['producto_precio'], 2) ?></p>
                        <div class="field has-addons">
                            <div class="control">
                                <input class="input cantidad" type="number" 
                                       value="<?= $item['cantidad'] ?>" min="1" 
                                       data-id="<?= $item['producto_id'] ?>">
                            </div>
                            <div class="control">
                                <button class="button is-danger eliminar" 
                                        data-id="<?= $item['producto_id'] ?>">
                                    <span class="icon is-small">
                                        <i class="fas fa-trash"></i>
                                    </span>
                                </button>
                            </div>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div class="has-text-right mt-5">
            <button id="generarFactura" class="button is-success is-medium">
                <span class="icon">
                    <i class="fas fa-credit-card"></i>
                </span>
                <span>Pagar ahora</span>
            </button>
        </div>
    <?php endif; ?>
</div>

<!-- Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    // Actualizar cantidad
    $('.cantidad').change(function() {
        const productoId = $(this).data('id');
        const nuevaCantidad = $(this).val();
        
        $.post('./php/actualizar_carrito.php', {
            action: 'actualizar',
            producto_id: productoId,
            cantidad: nuevaCantidad
        }, function(response) {
            if(response.error) {
                alert(response.error);
            }
        });
    });

    // Eliminar item
    $('.eliminar').click(function() {
        if(confirm('¿Eliminar este producto del carrito?')) {
            const productoId = $(this).data('id');
            
            $.post('./php/actualizar_carrito.php', {
                action: 'eliminar',
                producto_id: productoId
            }, function(response) {
                if(response.success) {
                    location.reload();
                }
            });
        }
    });

    // Generar factura
    $('#generarFactura').click(function() {
        $.post('./php/generar_factura.php', function(response) {
            if(response.success) {
                window.location.href = 'factura.php?id=' + response.factura_id;
            } else {
                alert(response.error || 'Error al generar factura');
            }
        });
    });
});
</script>