<?php
session_start();
require "main.php";

// 1. Crear factura
$conexion->query("INSERT INTO facturas (usuario_id, total) VALUES ({$_SESSION['id']}, 0)");
$factura_id = $conexion->lastInsertId();

// 2. Mover items del carrito a factura
$items = $conexion->query("SELECT * FROM carrito WHERE usuario_id = {$_SESSION['id']}");

$total = 0;
foreach($items as $item){
    $precio = $conexion->query("SELECT producto_precio FROM producto WHERE producto_id = {$item['producto_id']}")->fetchColumn();
    $subtotal = $precio * $item['cantidad'];
    
    $conexion->query("INSERT INTO detalles_factura VALUES (null, $factura_id, {$item['producto_id']}, {$item['cantidad']}, $precio)");
    $total += $subtotal;
}

// 3. Actualizar total
$conexion->query("UPDATE facturas SET total = $total WHERE factura_id = $factura_id");

// 4. Vaciar carrito
$conexion->query("DELETE FROM carrito WHERE usuario_id = {$_SESSION['id']}");

echo json_encode(['factura_id' => $factura_id]);
?>