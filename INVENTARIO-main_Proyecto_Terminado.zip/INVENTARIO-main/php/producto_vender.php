<?php
require_once "main.php";

/*== Verificar datos ==*/
$producto_id = limpiar_cadena($_POST['producto_id']);
$cantidad = limpiar_cadena($_POST['cantidad']);

/*== Validar stock ==*/
$check_producto = conexion();
$check_producto = $check_producto->query("SELECT * FROM producto WHERE producto_id='$producto_id'");

if($check_producto->rowCount()<=0){
    echo '
        <div class="notification is-danger">
            <strong>¡Error!</strong> El producto no existe.
        </div>
    ';
    exit();
}

$datos = $check_producto->fetch();
$stock_actual = $datos['producto_stock'];

if($cantidad > $stock_actual){
    echo '
        <div class="notification is-danger">
            <strong>¡Error!</strong> No hay suficiente stock.
        </div>
    ';
    exit();
}

/*== Registrar venta ==*/
$precio = $datos['producto_precio'];
$guardar_venta = conexion();
$guardar_venta = $guardar_venta->prepare("INSERT INTO vendido_parte(producto_id, usuario_id, cantidad, precio_unitario) VALUES(:producto, :usuario, :cantidad, :precio)");

$marcadores = [
    ":producto" => $producto_id,
    ":usuario" => $_SESSION['id'],
    ":cantidad" => $cantidad,
    ":precio" => $precio
];

if($guardar_venta->execute($marcadores)){
    /*== Actualizar stock ==*/
    $nuevo_stock = $stock_actual - $cantidad;
    $actualizar_stock = conexion();
    $actualizar_stock = $actualizar_stock->prepare("UPDATE producto SET producto_stock=:stock WHERE producto_id=:id");
    $actualizar_stock->execute([":stock"=>$nuevo_stock, ":id"=>$producto_id]);

    echo '
        <div class="notification is-success">
            <strong>¡Venta registrada!</strong>
        </div>
    ';
}else{
    echo '
        <div class="notification is-danger">
            <strong>¡Error!</strong> No se pudo registrar la venta.
        </div>
    ';
}
?>
