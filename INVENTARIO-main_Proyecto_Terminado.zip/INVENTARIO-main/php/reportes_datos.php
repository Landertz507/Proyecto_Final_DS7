<?php
ini_set('display_errors',1);
error_reporting(E_ALL);
require_once __DIR__ . "/main.php";
?>

<?php
if(empty($_GET['mes'])){
    echo '<div class="notification is-warning">Seleccione un mes y haga clic en "Generar Reporte"</div>';
    return;
}


// Procesar filtros
$categoria_id = isset($_GET['categoria_id']) ? (int)$_GET['categoria_id'] : 0;
$mes = isset($_GET['mes']) ? $_GET['mes'] : date('Y-m');

// Validar formato de fecha
if(!preg_match('/^\d{4}-\d{2}$/', $mes)){
    echo '<div class="notification is-danger">Formato de mes inválido</div>';
    return;
}

// Consulta para estadísticas
try {
    $query = "
        SELECT p.producto_nombre, SUM(v.cantidad) as total_vendido 
        FROM vendido_parte v
        INNER JOIN producto p ON v.producto_id = p.producto_id
        WHERE MONTH(v.fecha_venta) = MONTH(:mes)
        AND YEAR(v.fecha_venta) = YEAR(:mes)
        ".($categoria_id > 0 ? " AND p.categoria_id = :categoria_id" : "")."
        GROUP BY v.producto_id
        ORDER BY total_vendido DESC LIMIT 10";

    $stmt = conexion()->prepare($query);
    $stmt->bindValue(':mes', $mes.'-01');
    if($categoria_id > 0) $stmt->bindValue(':categoria_id', $categoria_id);
    $stmt->execute();
    
    $ventas = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    echo '<div class="notification is-danger">Error al generar reporte: '.$e->getMessage().'</div>';
    return;
}

// Mostrar resultados solo si hay datos
if(empty($ventas)){
    echo '<div class="notification is-warning">No hay ventas registradas para los filtros seleccionados</div>';
    return;
}
?>

<!-- Mostrar gráfico -->
<div class="box">
    <canvas id="graficoVentas" height="300"></canvas>
</div>

<!-- Tabla de productos más vendidos -->
<div class="box">
    <h3 class="title is-4">Top 10 productos más vendidos</h3>
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
        <thead>
            <tr>
                <th>Producto</th>
                <th>Unidades vendidas</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($ventas as $v): ?>
            <tr>
                <td><?= htmlspecialchars($v['producto_nombre']) ?></td>
                <td><?= $v['total_vendido'] ?></td>
                <td>$<?= number_format($v['total_vendido'] * $v['precio_unitario'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
    // Solo inicializar gráfico si existe el canvas
    if(document.getElementById('graficoVentas')){
        const ctx = document.getElementById('graficoVentas').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($ventas, 'producto_nombre')) ?>,
                datasets: [{
                    label: 'Unidades vendidas',
                    data: <?= json_encode(array_column($ventas, 'total_vendido')) ?>,
                    backgroundColor: '#36A2EB'
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }
});
</script>