<?php

require_once __DIR__ . "/main.php";


header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=reporte_ventas_".date('d-m-Y').".xls");

$categoria_id = isset($_GET['categoria_id']) ? (int)$_GET['categoria_id'] : 0;
$mes = isset($_GET['mes']) ? $_GET['mes'] : date('Y-m');

$query = "
    SELECT p.producto_codigo, p.producto_nombre, c.categoria_nombre, 
           SUM(v.cantidad) as total_vendido, SUM(v.precio_unitario * v.cantidad) as total_ingresos
    FROM vendido_parte v
    INNER JOIN producto p ON v.producto_id = p.producto_id
    INNER JOIN categoria c ON p.categoria_id = c.categoria_id
    WHERE MONTH(v.fecha_venta) = MONTH('$mes-01')
    AND YEAR(v.fecha_venta) = YEAR('$mes-01')
    " . ($categoria_id > 0 ? " AND p.categoria_id = $categoria_id" : "") . "
    GROUP BY v.producto_id
    ORDER BY total_vendido DESC";

$ventas = conexion()->query($query);

echo "<table border='1'>";
echo "<tr>
        <th>Código</th>
        <th>Producto</th>
        <th>Categoría</th>
        <th>Unidades vendidas</th>
        <th>Total ingresos</th>
      </tr>";

while($v = $ventas->fetch(PDO::FETCH_ASSOC)){
    echo "<tr>
            <td>".$v['producto_codigo']."</td>
            <td>".$v['producto_nombre']."</td>
            <td>".$v['categoria_nombre']."</td>
            <td>".$v['total_vendido']."</td>
            <td>$".number_format($v['total_ingresos'], 2)."</td>
          </tr>";
}
echo "</table>";
?>