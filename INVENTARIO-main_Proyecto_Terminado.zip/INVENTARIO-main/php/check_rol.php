<?php
// Verifica si el usuario es admin, si no, deniega acceso
function is_admin() {
    if (!isset($_SESSION['rol'])) {
        header("Location: login.php");
        exit();
    }
    return ($_SESSION['rol'] == 'admin');
}

// Ejemplo de uso en otros archivos:
// require_once "./php/check_rol.php";
// if (!is_admin()) { die("Acceso denegado"); }
?>