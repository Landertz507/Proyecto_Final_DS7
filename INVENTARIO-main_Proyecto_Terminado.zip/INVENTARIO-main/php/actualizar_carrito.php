<?php
session_start();
require "main.php";

if(!isset($_SESSION['id'])) {
    echo json_encode(['error' => 'Sesión no iniciada']);
    exit;
}

$action = $_POST['action'] ?? '';
$producto_id = (int)($_POST['producto_id'] ?? 0);

try {
    $conexion = conexion();
    
    switch($action) {
        case 'actualizar':
            $cantidad = (int)$_POST['cantidad'];
            $conexion->prepare("UPDATE carrito SET cantidad = ? WHERE producto_id = ? AND usuario_id = ?")
                   ->execute([$cantidad, $producto_id, $_SESSION['id']]);
            break;
            
        case 'eliminar':
            $conexion->prepare("DELETE FROM carrito WHERE producto_id = ? AND usuario_id = ?")
                   ->execute([$producto_id, $_SESSION['id']]);
            break;
    }
    
    echo json_encode(['success' => true]);
    
} catch(PDOException $e) {
    echo json_encode(['error' => 'Error en la base de datos: ' . $e->getMessage()]);
}
?>