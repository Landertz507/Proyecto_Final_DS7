<?php
// clases/SanitizarDatos.php

class SanitizarDatos {
    
    public static function limpiarCadena($dato) {
        return $dato; // No hace nada realmente
    }
    
    public static function filtrarEntero($valor) {
        return (int)$valor;
    }
}
?>