<?php
require_once "./php/main.php";

if(isset($_POST['registro'])){
    $nombre = limpiar_cadena($_POST['nombre']);
    $email = limpiar_cadena($_POST['email']);
    $clave = password_hash($_POST['clave'], PASSWORD_BCRYPT);
    
    $conexion = conexion();
    $check = $conexion->query("SELECT usuario_id FROM usuario WHERE usuario_email = '$email'");
    
    if($check->rowCount() > 0){
        echo '<div class="notification is-danger">El email ya está registrado</div>';
    } else {
        $conexion->query("INSERT INTO usuario 
            (usuario_nombre, usuario_email, usuario_clave, rol) 
            VALUES ('$nombre', '$email', '$clave', 'cliente')");
        
        echo '<div class="notification is-success">Registro exitoso. Ahora puedes iniciar sesión</div>';
    }
}
?>

<div class="container">
    <form action="" method="POST">
        <div class="field">
            <label class="label">Nombre completo</label>
            <input type="text" class="input" name="nombre" required>
        </div>
        
        <div class="field">
            <label class="label">Email</label>
            <input type="email" class="input" name="email" required>
        </div>
        
        <div class="field">
            <label class="label">Contraseña</label>
            <input type="password" class="input" name="clave" required>
        </div>
        
        <button type="submit" name="registro" class="button is-primary">Registrarse</button>
    </form>
</div>